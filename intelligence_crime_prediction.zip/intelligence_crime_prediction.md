```python
import pandas as pd
```


```python
import seaborn as sns
```


```python
import numpy as np
```


```python
import matplotlib.pyplot as plt
```


```python
from sklearn import linear_model
```


```python
%matplotlib inline
```


```python
data = pd.read_html('https://en.wikipedia.org/wiki/Counties_of_Kenya')
```


```python
data[0].head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Counties of KenyaKaunti za Kenya (Swahili)</th>
      <th>Counties of KenyaKaunti za Kenya (Swahili).1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Category</td>
      <td>Semi-devolved state</td>
    </tr>
  </tbody>
</table>
</div>




```python
data[2].head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>FormerProvince</th>
      <th>Area(km2)</th>
      <th>Population(2009 Census)</th>
      <th>Population(2019 Census)</th>
      <th>Capital</th>
      <th>Postal Abbreviations</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>Mombasa</td>
      <td>Coast</td>
      <td>212.5</td>
      <td>939370</td>
      <td>1208333</td>
      <td>Mombasa</td>
      <td>MSA</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>Kwale</td>
      <td>Coast</td>
      <td>8270.3</td>
      <td>649931</td>
      <td>866820</td>
      <td>Kwale</td>
      <td>KWL</td>
    </tr>
  </tbody>
</table>
</div>




```python
country_data = data[2]
```


```python
country_data[44:]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>FormerProvince</th>
      <th>Area(km2)</th>
      <th>Population(2009 Census)</th>
      <th>Population(2019 Census)</th>
      <th>Capital</th>
      <th>Postal Abbreviations</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>44</th>
      <td>45.0</td>
      <td>Kisii</td>
      <td>Nyanza</td>
      <td>1317.9</td>
      <td>1152282</td>
      <td>1266860</td>
      <td>Kisii</td>
      <td>KSI</td>
    </tr>
    <tr>
      <th>45</th>
      <td>46.0</td>
      <td>Nyamira</td>
      <td>Nyanza</td>
      <td>912.5</td>
      <td>598252</td>
      <td>605576</td>
      <td>Nyamira</td>
      <td>NMR</td>
    </tr>
    <tr>
      <th>46</th>
      <td>47.0</td>
      <td>Nairobi</td>
      <td>Nairobi</td>
      <td>694.9</td>
      <td>3138369</td>
      <td>4397073</td>
      <td>Nairobi</td>
      <td>NBI</td>
    </tr>
    <tr>
      <th>47</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>581309.0</td>
      <td>38610997</td>
      <td>47564296</td>
      <td>Nairobi</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
country_data.drop(47,inplace=True)
```


```python
country_data[44:]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>FormerProvince</th>
      <th>Area(km2)</th>
      <th>Population(2009 Census)</th>
      <th>Population(2019 Census)</th>
      <th>Capital</th>
      <th>Postal Abbreviations</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>44</th>
      <td>45.0</td>
      <td>Kisii</td>
      <td>Nyanza</td>
      <td>1317.9</td>
      <td>1152282</td>
      <td>1266860</td>
      <td>Kisii</td>
      <td>KSI</td>
    </tr>
    <tr>
      <th>45</th>
      <td>46.0</td>
      <td>Nyamira</td>
      <td>Nyanza</td>
      <td>912.5</td>
      <td>598252</td>
      <td>605576</td>
      <td>Nyamira</td>
      <td>NMR</td>
    </tr>
    <tr>
      <th>46</th>
      <td>47.0</td>
      <td>Nairobi</td>
      <td>Nairobi</td>
      <td>694.9</td>
      <td>3138369</td>
      <td>4397073</td>
      <td>Nairobi</td>
      <td>NBI</td>
    </tr>
  </tbody>
</table>
</div>




```python

country_data.drop(['Population(2009 Census)','FormerProvince','Capital'],axis=1,inplace=True)
```


```python
country_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>Area(km2)</th>
      <th>Population(2019 Census)</th>
      <th>Postal Abbreviations</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>Mombasa</td>
      <td>212.5</td>
      <td>1208333</td>
      <td>MSA</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>Kwale</td>
      <td>8270.3</td>
      <td>866820</td>
      <td>KWL</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>Kilifi</td>
      <td>12245.9</td>
      <td>1453787</td>
      <td>KLF</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>Tana River</td>
      <td>35375.8</td>
      <td>315943</td>
      <td>TRV</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>Lamu</td>
      <td>6497.7</td>
      <td>143920</td>
      <td>LMU</td>
    </tr>
  </tbody>
</table>
</div>




```python
country_data.to_excel('country_crime.xlsx',sheet_name='country_data')
```


```python
crime_data=pd.read_excel('crime_data.xlsx')
```


```python
crime_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>(COUNTIES)</th>
      <th>HOMICIDE</th>
      <th>OFFENCES AGAINST MORALITY</th>
      <th>OTHER OFFENCES AGAINST PERSONS</th>
      <th>ROBBERY</th>
      <th>BREAKINGS</th>
      <th>THEFT OF STOCK</th>
      <th>STEALING</th>
      <th>THEFT BY SERVANT</th>
      <th>VEHICLE AND OTHER THEFTS</th>
      <th>DANGEROUS DRUGS</th>
      <th>TRAFFIC OFFENCES</th>
      <th>CRIMINAL DAMAGE</th>
      <th>ECONOMIC CRIMES</th>
      <th>CORRUPTION</th>
      <th>OFFENCES INVOLVING POLICE OFFICERS</th>
      <th>OFFENCES  INVOLVING TOURIST</th>
      <th>OTHER PENAL CODE OFFENCES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mombasa</td>
      <td>25</td>
      <td>280</td>
      <td>348</td>
      <td>85</td>
      <td>119</td>
      <td>4</td>
      <td>460</td>
      <td>64</td>
      <td>51</td>
      <td>269</td>
      <td>42</td>
      <td>79</td>
      <td>180</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>220</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kwale</td>
      <td>52</td>
      <td>230</td>
      <td>243</td>
      <td>17</td>
      <td>44</td>
      <td>26</td>
      <td>101</td>
      <td>16</td>
      <td>11</td>
      <td>23</td>
      <td>0</td>
      <td>44</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>78</td>
    </tr>
    <tr>
      <th>2</th>
      <td>kilifi</td>
      <td>124</td>
      <td>328</td>
      <td>356</td>
      <td>25</td>
      <td>95</td>
      <td>28</td>
      <td>243</td>
      <td>37</td>
      <td>17</td>
      <td>81</td>
      <td>8</td>
      <td>86</td>
      <td>106</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>263</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Tana River</td>
      <td>11</td>
      <td>72</td>
      <td>129</td>
      <td>7</td>
      <td>25</td>
      <td>18</td>
      <td>43</td>
      <td>7</td>
      <td>5</td>
      <td>19</td>
      <td>0</td>
      <td>20</td>
      <td>6</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>33</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Lamu</td>
      <td>9</td>
      <td>64</td>
      <td>103</td>
      <td>14</td>
      <td>27</td>
      <td>13</td>
      <td>44</td>
      <td>2</td>
      <td>2</td>
      <td>36</td>
      <td>0</td>
      <td>15</td>
      <td>7</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>40</td>
    </tr>
  </tbody>
</table>
</div>




```python
# df=pd.merge(country_data,crime_data,left_on='County',right_on='(COUNTIES)')
```


```python
drug_data=pd.read_excel('try.xlsx')
```


```python
drug_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>COUNTY/FORMATION</th>
      <th>TYPE OF DRUG</th>
      <th>POSSESSION</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>HOMA BAY</td>
      <td>BHANG</td>
      <td>62</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SIAYA</td>
      <td>BHANG</td>
      <td>49</td>
    </tr>
    <tr>
      <th>2</th>
      <td>MIGORI</td>
      <td>BHANG</td>
      <td>15</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NYAMIRA</td>
      <td>BHANG</td>
      <td>38</td>
    </tr>
    <tr>
      <th>4</th>
      <td>KISII</td>
      <td>BHANG</td>
      <td>90</td>
    </tr>
  </tbody>
</table>
</div>




```python
pivot=np.round(pd.pivot_table(drug_data,values='POSSESSION',index='COUNTY/FORMATION',columns='TYPE OF DRUG'))
```


```python
pivot.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>TYPE OF DRUG</th>
      <th>BHANG</th>
      <th>HEROINE</th>
    </tr>
    <tr>
      <th>COUNTY/FORMATION</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>BARINGO</th>
      <td>12.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>BOMET</th>
      <td>28.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>BUNGOMA</th>
      <td>37.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>BUSIA</th>
      <td>64.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>E/MARAKWET</th>
      <td>15.0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
pivot.drop(['HEROINE'],axis=1,inplace=True)
```


```python
pivot.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>TYPE OF DRUG</th>
      <th>BHANG</th>
    </tr>
    <tr>
      <th>COUNTY/FORMATION</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>BARINGO</th>
      <td>12.0</td>
    </tr>
    <tr>
      <th>BOMET</th>
      <td>28.0</td>
    </tr>
    <tr>
      <th>BUNGOMA</th>
      <td>37.0</td>
    </tr>
    <tr>
      <th>BUSIA</th>
      <td>64.0</td>
    </tr>
    <tr>
      <th>E/MARAKWET</th>
      <td>15.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df=pd.merge(country_data,crime_data,left_on='County',right_on='(COUNTIES)')
```


```python
# county_info = pd.merge(df, pivot, left_on='County',right_on='TYPE OF DRUG')
# need to check it
```


```python

```


```python
county_info.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>Area(km2)</th>
      <th>Population(2019 Census)</th>
      <th>Postal Abbreviations</th>
      <th>(COUNTIES)</th>
      <th>HOMICIDE</th>
      <th>OFFENCES AGAINST MORALITY</th>
      <th>OTHER OFFENCES AGAINST PERSONS</th>
      <th>ROBBERY</th>
      <th>...</th>
      <th>TRAFFIC OFFENCES</th>
      <th>CRIMINAL DAMAGE</th>
      <th>ECONOMIC CRIMES</th>
      <th>CORRUPTION</th>
      <th>OFFENCES INVOLVING POLICE OFFICERS</th>
      <th>OFFENCES  INVOLVING TOURIST</th>
      <th>OTHER PENAL CODE OFFENCES</th>
      <th>COUNTY/FORMATION</th>
      <th>TYPE OF DRUG</th>
      <th>POSSESSION</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 26 columns</p>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>Area(km2)</th>
      <th>Population(2019 Census)</th>
      <th>Postal Abbreviations</th>
      <th>(COUNTIES)</th>
      <th>HOMICIDE</th>
      <th>OFFENCES AGAINST MORALITY</th>
      <th>OTHER OFFENCES AGAINST PERSONS</th>
      <th>ROBBERY</th>
      <th>...</th>
      <th>THEFT BY SERVANT</th>
      <th>VEHICLE AND OTHER THEFTS</th>
      <th>DANGEROUS DRUGS</th>
      <th>TRAFFIC OFFENCES</th>
      <th>CRIMINAL DAMAGE</th>
      <th>ECONOMIC CRIMES</th>
      <th>CORRUPTION</th>
      <th>OFFENCES INVOLVING POLICE OFFICERS</th>
      <th>OFFENCES  INVOLVING TOURIST</th>
      <th>OTHER PENAL CODE OFFENCES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>Mombasa</td>
      <td>212.5</td>
      <td>1208333</td>
      <td>MSA</td>
      <td>Mombasa</td>
      <td>25</td>
      <td>280</td>
      <td>348</td>
      <td>85</td>
      <td>...</td>
      <td>64</td>
      <td>51</td>
      <td>269</td>
      <td>42</td>
      <td>79</td>
      <td>180</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>220</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>Kwale</td>
      <td>8270.3</td>
      <td>866820</td>
      <td>KWL</td>
      <td>Kwale</td>
      <td>52</td>
      <td>230</td>
      <td>243</td>
      <td>17</td>
      <td>...</td>
      <td>16</td>
      <td>11</td>
      <td>23</td>
      <td>0</td>
      <td>44</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>78</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.0</td>
      <td>Tana River</td>
      <td>35375.8</td>
      <td>315943</td>
      <td>TRV</td>
      <td>Tana River</td>
      <td>11</td>
      <td>72</td>
      <td>129</td>
      <td>7</td>
      <td>...</td>
      <td>7</td>
      <td>5</td>
      <td>19</td>
      <td>0</td>
      <td>20</td>
      <td>6</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>33</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5.0</td>
      <td>Lamu</td>
      <td>6497.7</td>
      <td>143920</td>
      <td>LMU</td>
      <td>Lamu</td>
      <td>9</td>
      <td>64</td>
      <td>103</td>
      <td>14</td>
      <td>...</td>
      <td>2</td>
      <td>2</td>
      <td>36</td>
      <td>0</td>
      <td>15</td>
      <td>7</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>40</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8.0</td>
      <td>Wajir</td>
      <td>55840.6</td>
      <td>781263</td>
      <td>WJR</td>
      <td>Wajir</td>
      <td>3</td>
      <td>23</td>
      <td>132</td>
      <td>2</td>
      <td>...</td>
      <td>0</td>
      <td>4</td>
      <td>22</td>
      <td>0</td>
      <td>7</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>21</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>




```python
df.columns
```




    Index(['Code', 'County', 'Area(km2)', 'Population(2019 Census)',
           'Postal Abbreviations', '(COUNTIES)', 'HOMICIDE',
           'OFFENCES AGAINST MORALITY', 'OTHER OFFENCES AGAINST PERSONS',
           'ROBBERY', 'BREAKINGS', 'THEFT OF STOCK', 'STEALING',
           'THEFT BY SERVANT', 'VEHICLE AND OTHER THEFTS', 'DANGEROUS DRUGS',
           'TRAFFIC OFFENCES', 'CRIMINAL DAMAGE', 'ECONOMIC CRIMES', 'CORRUPTION',
           'OFFENCES INVOLVING POLICE OFFICERS', 'OFFENCES  INVOLVING TOURIST',
           'OTHER PENAL CODE OFFENCES'],
          dtype='object')




```python
df.drop(['OFFENCES AGAINST MORALITY','THEFT OF STOCK',
       'THEFT BY SERVANT', 'VEHICLE AND OTHER THEFTS', 'DANGEROUS DRUGS',
       'TRAFFIC OFFENCES', 'CRIMINAL DAMAGE', 'ECONOMIC CRIMES', 'CORRUPTION',
       'OFFENCES INVOLVING POLICE OFFICERS', 'OFFENCES  INVOLVING TOURIST',
       'OTHER PENAL CODE OFFENCES',], axis=1, inplace=True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>Area(km2)</th>
      <th>Population(2019 Census)</th>
      <th>Postal Abbreviations</th>
      <th>(COUNTIES)</th>
      <th>HOMICIDE</th>
      <th>OTHER OFFENCES AGAINST PERSONS</th>
      <th>ROBBERY</th>
      <th>BREAKINGS</th>
      <th>STEALING</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>Mombasa</td>
      <td>212.5</td>
      <td>1208333</td>
      <td>MSA</td>
      <td>Mombasa</td>
      <td>25</td>
      <td>348</td>
      <td>85</td>
      <td>119</td>
      <td>460</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>Kwale</td>
      <td>8270.3</td>
      <td>866820</td>
      <td>KWL</td>
      <td>Kwale</td>
      <td>52</td>
      <td>243</td>
      <td>17</td>
      <td>44</td>
      <td>101</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.0</td>
      <td>Tana River</td>
      <td>35375.8</td>
      <td>315943</td>
      <td>TRV</td>
      <td>Tana River</td>
      <td>11</td>
      <td>129</td>
      <td>7</td>
      <td>25</td>
      <td>43</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5.0</td>
      <td>Lamu</td>
      <td>6497.7</td>
      <td>143920</td>
      <td>LMU</td>
      <td>Lamu</td>
      <td>9</td>
      <td>103</td>
      <td>14</td>
      <td>27</td>
      <td>44</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8.0</td>
      <td>Wajir</td>
      <td>55840.6</td>
      <td>781263</td>
      <td>WJR</td>
      <td>Wajir</td>
      <td>3</td>
      <td>132</td>
      <td>2</td>
      <td>1</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.drop(['(COUNTIES)'],axis=1,inplace=True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>Area(km2)</th>
      <th>Population(2019 Census)</th>
      <th>Postal Abbreviations</th>
      <th>HOMICIDE</th>
      <th>OTHER OFFENCES AGAINST PERSONS</th>
      <th>ROBBERY</th>
      <th>BREAKINGS</th>
      <th>STEALING</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>Mombasa</td>
      <td>212.5</td>
      <td>1208333</td>
      <td>MSA</td>
      <td>25</td>
      <td>348</td>
      <td>85</td>
      <td>119</td>
      <td>460</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>Kwale</td>
      <td>8270.3</td>
      <td>866820</td>
      <td>KWL</td>
      <td>52</td>
      <td>243</td>
      <td>17</td>
      <td>44</td>
      <td>101</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.0</td>
      <td>Tana River</td>
      <td>35375.8</td>
      <td>315943</td>
      <td>TRV</td>
      <td>11</td>
      <td>129</td>
      <td>7</td>
      <td>25</td>
      <td>43</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5.0</td>
      <td>Lamu</td>
      <td>6497.7</td>
      <td>143920</td>
      <td>LMU</td>
      <td>9</td>
      <td>103</td>
      <td>14</td>
      <td>27</td>
      <td>44</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8.0</td>
      <td>Wajir</td>
      <td>55840.6</td>
      <td>781263</td>
      <td>WJR</td>
      <td>3</td>
      <td>132</td>
      <td>2</td>
      <td>1</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
</div>




```python

df['Homicide_rate (per 10,000 people)'] = (df['ROBBERY']/df['Population(2019 Census)']*10000)
df['other_offence_against_person (per 10,000 people)'] = (df['OTHER OFFENCES AGAINST PERSONS']/df['Population(2019 Census)']*10000)
df['Robbery_rate (per 10,000 people)'] = (df['ROBBERY']/df['Population(2019 Census)']*10000)
df['Stealing_rate (per 10,000 people)'] = (df['STEALING']/df['Population(2019 Census)']*10000)
df['Breaking_rate (per 10,000 people)'] = (df['BREAKINGS']/df['Population(2019 Census)']*10000)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Code</th>
      <th>County</th>
      <th>Area(km2)</th>
      <th>Population(2019 Census)</th>
      <th>Postal Abbreviations</th>
      <th>HOMICIDE</th>
      <th>OTHER OFFENCES AGAINST PERSONS</th>
      <th>ROBBERY</th>
      <th>BREAKINGS</th>
      <th>STEALING</th>
      <th>Homicide_rate (per 10,000 people)</th>
      <th>other_offence_against_person (per 10,000 people)</th>
      <th>Robbery_rate (per 10,000 people)</th>
      <th>Stealing_rate (per 10,000 people)</th>
      <th>Breaking_rate (per 10,000 people)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>Mombasa</td>
      <td>212.5</td>
      <td>1208333</td>
      <td>MSA</td>
      <td>25</td>
      <td>348</td>
      <td>85</td>
      <td>119</td>
      <td>460</td>
      <td>0.703448</td>
      <td>2.880001</td>
      <td>0.703448</td>
      <td>3.806898</td>
      <td>0.984828</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>Kwale</td>
      <td>8270.3</td>
      <td>866820</td>
      <td>KWL</td>
      <td>52</td>
      <td>243</td>
      <td>17</td>
      <td>44</td>
      <td>101</td>
      <td>0.196119</td>
      <td>2.803350</td>
      <td>0.196119</td>
      <td>1.165178</td>
      <td>0.507603</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.0</td>
      <td>Tana River</td>
      <td>35375.8</td>
      <td>315943</td>
      <td>TRV</td>
      <td>11</td>
      <td>129</td>
      <td>7</td>
      <td>25</td>
      <td>43</td>
      <td>0.221559</td>
      <td>4.083015</td>
      <td>0.221559</td>
      <td>1.361005</td>
      <td>0.791282</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5.0</td>
      <td>Lamu</td>
      <td>6497.7</td>
      <td>143920</td>
      <td>LMU</td>
      <td>9</td>
      <td>103</td>
      <td>14</td>
      <td>27</td>
      <td>44</td>
      <td>0.972763</td>
      <td>7.156754</td>
      <td>0.972763</td>
      <td>3.057254</td>
      <td>1.876042</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8.0</td>
      <td>Wajir</td>
      <td>55840.6</td>
      <td>781263</td>
      <td>WJR</td>
      <td>3</td>
      <td>132</td>
      <td>2</td>
      <td>1</td>
      <td>12</td>
      <td>0.025600</td>
      <td>1.689572</td>
      <td>0.025600</td>
      <td>0.153597</td>
      <td>0.012800</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[['County', 'Robbery_rate (per 10,000 people)']].sort_values('Robbery_rate (per 10,000 people)', ascending= False).head()
#countries with the highest crime rate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>County</th>
      <th>Robbery_rate (per 10,000 people)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>16</th>
      <td>Kiambu</td>
      <td>1.244967</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lamu</td>
      <td>0.972763</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Machakos</td>
      <td>0.900184</td>
    </tr>
    <tr>
      <th>39</th>
      <td>Nairobi</td>
      <td>0.818726</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Nyeri</td>
      <td>0.777171</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns
```




    Index(['Code', 'County', 'Area(km2)', 'Population(2019 Census)',
           'Postal Abbreviations', 'HOMICIDE', 'OTHER OFFENCES AGAINST PERSONS',
           'ROBBERY', 'BREAKINGS', 'STEALING', 'Homicide_rate (per 10,000 people)',
           'other_offence_against_person (per 10,000 people)',
           'Robbery_rate (per 10,000 people)', 'Stealing_rate (per 10,000 people)',
           'Breaking_rate (per 10,000 people)'],
          dtype='object')




```python

axis_y_homice_rate = df[['County','Homicide_rate (per 10,000 people)']].sort_values('Homicide_rate (per 10,000 people)', ascending= False).head(10)['Homicide_rate (per 10,000 people)']
axis_x_homice_rate_county = df[['County','Homicide_rate (per 10,000 people)']].sort_values('Homicide_rate (per 10,000 people)', ascending= False).head(10)['County']

axis_y_other_offense_rate = df[['County','other_offence_against_person (per 10,000 people)']].sort_values('other_offence_against_person (per 10,000 people)', ascending= False).head(10)['other_offence_against_person (per 10,000 people)']
axis_x_other_offense_rate_county = df[['County','other_offence_against_person (per 10,000 people)']].sort_values('other_offence_against_person (per 10,000 people)', ascending= False).head(10)['County']

axis_y_robbery_rate = df[['County', 'Robbery_rate (per 10,000 people)']].sort_values('Robbery_rate (per 10,000 people)', ascending= False).head(10)['Robbery_rate (per 10,000 people)']
axis_x_robbery_rate_counties = df[['County', 'Robbery_rate (per 10,000 people)']].sort_values('Robbery_rate (per 10,000 people)', ascending= False).head(10)['County']

axis_y_Stealing_rate = df[['County', 'Stealing_rate (per 10,000 people)']].sort_values('Stealing_rate (per 10,000 people)', ascending= False).head(10)['Stealing_rate (per 10,000 people)']
axis_x_Stealing_rate_counties = df[['County', 'Stealing_rate (per 10,000 people)']].sort_values('Stealing_rate (per 10,000 people)', ascending= False).head(10)['County']

axis_y_Breaking_rate = df[['County','Breaking_rate (per 10,000 people)']].sort_values('Breaking_rate (per 10,000 people)', ascending= False).head(10)['Breaking_rate (per 10,000 people)']
axis_x_Breaking_rate_county = df[['County','Breaking_rate (per 10,000 people)']].sort_values('Breaking_rate (per 10,000 people)', ascending= False).head(10)['County']

# axis_y_total_crime_rate = df[['County','total_crime_rate (per 10,000 people)']].sort_values('total_crime_rate (per 10,000 people)', ascending= False).head(10)['total_crime_rate (per 10,000 people)']
# axis_x_total_crime_rate_county = df[['County','total_crime_rate (per 10,000 people)']].sort_values('total_crime_rate (per 10,000 people)', asc)
```


```python
fig, ax =plt.subplots(nrows= 5, ncols=1, figsize=(10,30))
ax[0].bar(axis_x_homice_rate_county, axis_y_homice_rate, color='red')
ax[0].set_title('Homicide Rate')
ax[0].set_ylabel('Homicide(s) per 10000 people')

# homicide plotting

ax[1].bar(axis_x_other_offense_rate_county, axis_y_other_offense_rate, color='maroon')
ax[1].set_title('Rate of other offences against People')
ax[1].set_ylabel('Other offence(s) against People per 10000 people')


# rate of other offenses


ax[2].bar(axis_x_robbery_rate_counties, axis_y_robbery_rate, color='black')
ax[2].set_title('Robbery rate')
ax[2].set_ylabel('Robbery(s) per 10000 people')


# robbery rate


ax[3].bar(axis_x_Stealing_rate_counties, axis_y_Stealing_rate, color='purple')
ax[3].set_title('Stealing rate')
ax[3].set_ylabel('Stealing(s) per 10000 people')


# stealing people


ax[4].bar(axis_x_Breaking_rate_county, axis_y_Breaking_rate, color='green')
ax[4].set_title('Breaking rate')
ax[4].set_ylabel('Breaking(s) per 10000 people')


# breaking rate of people

plt.tight_layout()
plt.show()

```


    
![png](output_40_0.png)
    



```python
#create new column for each crime 10 KM squared people
```


```python
area_info = df['Area(km2)']/10

df['Homicide_rate (per 10KM2)'] = (df['HOMICIDE']/area_info)
df['other_offence_against_person (per 10KM2)'] = (df['other_offence_against_person (per 10,000 people)']/area_info)
df['Robbery_rate (per 10KM2)'] = (df['ROBBERY']/area_info)
df['Stealing_rate (per 10KM2)'] = (df['STEALING']/area_info)
df['Breaking_rate (per 10KM2)'] = (df['BREAKINGS']/area_info)

```


```python
df[['County', 'Robbery_rate (per 10KM2)']].sort_values('Robbery_rate (per 10KM2)', ascending= False).head()
# country with
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>County</th>
      <th>Robbery_rate (per 10KM2)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>39</th>
      <td>Nairobi</td>
      <td>5.180602</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Mombasa</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Kiambu</td>
      <td>1.228973</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Vihiga</td>
      <td>0.564653</td>
    </tr>
    <tr>
      <th>38</th>
      <td>Nyamira</td>
      <td>0.493151</td>
    </tr>
  </tbody>
</table>
</div>




```python
axis_y_10KM2_homice_rate = df[['County','Homicide_rate (per 10KM2)']].sort_values('Homicide_rate (per 10KM2)', ascending= False).head(10)['Homicide_rate (per 10KM2)']
axis_x_10KM2_homice_rate_county = df[['County','Homicide_rate (per 10KM2)']].sort_values('Homicide_rate (per 10KM2)', ascending= False).head(10)['County']

axis_y_10KM2_other_offense_rate = df[['County','other_offence_against_person (per 10KM2)']].sort_values('other_offence_against_person (per 10KM2)', ascending= False).head(10)['other_offence_against_person (per 10KM2)']
axis_x_10KM2_other_offense_rate_county = df[['County','other_offence_against_person (per 10KM2)']].sort_values('other_offence_against_person (per 10KM2)', ascending= False).head(10)['County']

axis_y_10KM2_robbery_rate = df[['County', 'Robbery_rate (per 10KM2)']].sort_values('Robbery_rate (per 10KM2)', ascending= False).head(10)['Robbery_rate (per 10KM2)']
axis_x_10KM2_robbery_rate_counties = df[['County', 'Robbery_rate (per 10KM2)']].sort_values('Robbery_rate (per 10KM2)', ascending= False).head(10)['County']

axis_y_10KM2_Stealing_rate = df[['County', 'Stealing_rate (per 10KM2)']].sort_values('Stealing_rate (per 10KM2)', ascending= False).head(10)['Stealing_rate (per 10KM2)']
axis_x_10KM2_Stealing_rate_counties = df[['County', 'Stealing_rate (per 10KM2)']].sort_values('Stealing_rate (per 10KM2)', ascending= False).head(10)['County']

axis_y_10KM2_Breaking_rate = df[['County','Breaking_rate (per 10KM2)']].sort_values('Breaking_rate (per 10KM2)', ascending= False).head(10)['Breaking_rate (per 10KM2)']
axis_x_10KM2_Breaking_rate_county = df[['County','Breaking_rate (per 10KM2)']].sort_values('Breaking_rate (per 10KM2)', ascending= False).head(10)['County']


```


```python
fig, ax =plt.subplots(nrows= 5, ncols=1, figsize=(10,30))
ax[0].bar(axis_x_10KM2_homice_rate_county, axis_y_10KM2_homice_rate, color='red')
ax[0].set_title('Homicide Rate per 10KM2')
ax[0].set_ylabel('Homicide(s) per 10KM2')

ax[1].bar(axis_x_other_offense_rate_county, axis_y_other_offense_rate, color='maroon')
ax[1].set_title('Rate of other offences against People per 10KM2')
ax[1].set_ylabel('Other offence(s) against People per 10KM2')

ax[2].bar(axis_x_robbery_rate_counties, axis_y_robbery_rate, color='black')
ax[2].set_title('Robbery rate per 10KM2')
ax[2].set_ylabel('Robbery(s) per 10KM2')

ax[3].bar(axis_x_Stealing_rate_counties, axis_y_Stealing_rate, color='purple')
ax[3].set_title('Stealing rate 10KM2')
ax[3].set_ylabel('Stealing(s) per 10KM2')

ax[4].bar(axis_x_Breaking_rate_county, axis_y_Breaking_rate, color='green')
ax[4].set_title('Breaking rate per 10KM2')
ax[4].set_ylabel('Breaking(s) per 10KM2')


plt.tight_layout()
plt.show()

# for each crime per 10 KM2
```


    
![png](output_45_0.png)
    



```python
sns.displot(county_info['Area(km2)'], kde=True)
```




    <seaborn.axisgrid.FacetGrid at 0x2236fe8f0d0>




    
![png](output_46_1.png)
    



```python
sns.displot(df['Population(2019 Census)'], kde=True)
```




    <seaborn.axisgrid.FacetGrid at 0x22370e149d0>




    
![png](output_47_1.png)
    



```python
df['log_Area(km2)'] = np.log(county_info['Area(km2)'])
df['log_Population(2019 Census)'] = np.log(df['Population(2019 Census)'])
```


```python
sns.displot(df['log_Area(km2)'], kde=True)
```

    C:\Users\admin\anaconda3\lib\site-packages\seaborn\distributions.py:306: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    




    <seaborn.axisgrid.FacetGrid at 0x22370ee08b0>




    
![png](output_49_2.png)
    



```python
sns.displot(df['log_Population(2019 Census)'], kde=True)
```




    <seaborn.axisgrid.FacetGrid at 0x22370ea24f0>




    
![png](output_50_1.png)
    



```python

```
